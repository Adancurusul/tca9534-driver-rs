/**
 * @file tca9534_stm32.h
 * @brief TCA9534 STM32 HAL Integration Functions
 * 
 * This header declares convenience functions for using TCA9534 with STM32 HAL.
 * 
 * @author STM32 Integration
 * @date 2025
 */

#ifndef TCA9534_STM32_H
#define TCA9534_STM32_H

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
#include "tca9534.h"

// =============================================================================
// STM32 Convenience Functions
// =============================================================================

/**
 * @brief Initialize TCA9534 with STM32 HAL I2C
 * 
 * @param hi2c STM32 I2C handle pointer
 * @param device_addr I2C device address (7-bit), use TCA9534_ADDR_xxx constants
 * @param timeout_ms I2C timeout in milliseconds (0 = use default)
 * @return TCA9534 error code
 */
tca9534_error_t TCA9534_STM32_Init(I2C_HandleTypeDef* hi2c, uint8_t device_addr, uint32_t timeout_ms);

/**
 * @brief Initialize TCA9534 with default settings
 * 
 * @param hi2c STM32 I2C handle pointer
 * @return TCA9534 error code
 */
tca9534_error_t TCA9534_STM32_Init_Default(I2C_HandleTypeDef* hi2c);

/**
 * @brief Get the global TCA9534 handle
 * 
 * @return Pointer to the global TCA9534 handle
 */
tca9534_handle_t* TCA9534_STM32_GetHandle(void);

/**
 * @brief Get the last HAL I2C status
 * 
 * @return HAL status code
 */
HAL_StatusTypeDef TCA9534_STM32_GetLastHALStatus(void);

/**
 * @brief Check if TCA9534 device is ready
 * 
 * @return TCA9534_OK if device is ready, error code otherwise
 */
tca9534_error_t TCA9534_STM32_IsDeviceReady(void);

// =============================================================================
// End of declarations
// =============================================================================

#ifdef __cplusplus
}
#endif

#endif /* TCA9534_STM32_H */ 