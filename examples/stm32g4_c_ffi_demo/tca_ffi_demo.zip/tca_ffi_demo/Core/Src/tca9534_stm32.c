/**
 * @file tca9534_stm32.c
 * @brief TCA9534 STM32 HAL I2C Transport Implementation
 * 
 * This file provides STM32 HAL I2C transport functions for TCA9534 C FFI interface.
 * It implements the I2C function pointers required by the TCA9534 C API.
 * 
 * @author STM32 Integration
 * @date 2025
 */

#include "main.h"
#include "tca9534.h"

// =============================================================================
// Configuration
// =============================================================================

/** Default I2C timeout in milliseconds */
#define TCA9534_I2C_TIMEOUT_MS    100

// =============================================================================
// STM32 I2C Context Structure
// =============================================================================

/**
 * @brief STM32 I2C context for TCA9534
 */
typedef struct {
    I2C_HandleTypeDef* hi2c;        /**< STM32 I2C handle */
    uint32_t timeout_ms;            /**< I2C timeout in milliseconds */
    HAL_StatusTypeDef last_status;  /**< Last HAL operation status */
} stm32_i2c_context_t;

// =============================================================================
// STM32 HAL I2C Transport Functions
// =============================================================================

/**
 * @brief STM32 HAL I2C write function
 * 
 * @param ctx STM32 I2C context pointer
 * @param addr I2C device address (7-bit)
 * @param data Data to write
 * @param len Number of bytes to write
 * @return 0 on success, non-zero on error
 */
int stm32_i2c_write(void* ctx, uint8_t addr, const uint8_t* data, size_t len) {
    stm32_i2c_context_t* i2c_ctx = (stm32_i2c_context_t*)ctx;
    
    if (ctx == NULL || data == NULL) {
        return -1;
    }
    
    // Convert 7-bit address to 8-bit format for HAL
    uint16_t device_addr = (uint16_t)(addr << 1);
    
    // Perform I2C write
    i2c_ctx->last_status = HAL_I2C_Master_Transmit(
        i2c_ctx->hi2c, 
        device_addr, 
        (uint8_t*)data, 
        (uint16_t)len, 
        i2c_ctx->timeout_ms
    );
    
    return (i2c_ctx->last_status == HAL_OK) ? 0 : -1;
}

/**
 * @brief STM32 HAL I2C read function
 * 
 * @param ctx STM32 I2C context pointer
 * @param addr I2C device address (7-bit)
 * @param data Buffer to store read data
 * @param len Number of bytes to read
 * @return 0 on success, non-zero on error
 */
int stm32_i2c_read(void* ctx, uint8_t addr, uint8_t* data, size_t len) {
    stm32_i2c_context_t* i2c_ctx = (stm32_i2c_context_t*)ctx;
    
    if (ctx == NULL || data == NULL) {
        return -1;
    }
    
    // Convert 7-bit address to 8-bit format for HAL
    uint16_t device_addr = (uint16_t)(addr << 1);
    
    // Perform I2C read
    i2c_ctx->last_status = HAL_I2C_Master_Receive(
        i2c_ctx->hi2c, 
        device_addr, 
        data, 
        (uint16_t)len, 
        i2c_ctx->timeout_ms
    );
    
    return (i2c_ctx->last_status == HAL_OK) ? 0 : -1;
}

/**
 * @brief STM32 HAL I2C write-read function
 * 
 * @param ctx STM32 I2C context pointer
 * @param addr I2C device address (7-bit)
 * @param wr_data Data to write
 * @param wr_len Number of bytes to write
 * @param rd_data Buffer to store read data
 * @param rd_len Number of bytes to read
 * @return 0 on success, non-zero on error
 */
int stm32_i2c_write_read(void* ctx, uint8_t addr, const uint8_t* wr_data, 
                        size_t wr_len, uint8_t* rd_data, size_t rd_len) {
    stm32_i2c_context_t* i2c_ctx = (stm32_i2c_context_t*)ctx;
    
    if (ctx == NULL || wr_data == NULL || rd_data == NULL) {
        return -1;
    }
    
    // Convert 7-bit address to 8-bit format for HAL
    uint16_t device_addr = (uint16_t)(addr << 1);
    
    // Perform I2C write-read (transmit then receive)
    i2c_ctx->last_status = HAL_I2C_Master_Transmit(
        i2c_ctx->hi2c, 
        device_addr, 
        (uint8_t*)wr_data, 
        (uint16_t)wr_len, 
        i2c_ctx->timeout_ms
    );
    
    if (i2c_ctx->last_status != HAL_OK) {
        return -1;
    }
    
    i2c_ctx->last_status = HAL_I2C_Master_Receive(
        i2c_ctx->hi2c, 
        device_addr, 
        rd_data, 
        (uint16_t)rd_len, 
        i2c_ctx->timeout_ms
    );
    
    return (i2c_ctx->last_status == HAL_OK) ? 0 : -1;
}

// =============================================================================
// Global Variables
// =============================================================================

/** STM32 I2C context instance */
static stm32_i2c_context_t g_i2c_context = {0};

/** TCA9534 I2C operations structure */
static tca9534_i2c_ops_t g_i2c_ops = {
    .write = stm32_i2c_write,
    .read = stm32_i2c_read,
    .write_read = stm32_i2c_write_read
};

/** TCA9534 device handle */
static tca9534_handle_t g_tca9534_handle = {0};

// =============================================================================
// Convenience Functions
// =============================================================================

/**
 * @brief Initialize TCA9534 with STM32 HAL I2C
 * 
 * @param hi2c STM32 I2C handle pointer
 * @param device_addr I2C device address (7-bit), use TCA9534_ADDR_xxx constants
 * @param timeout_ms I2C timeout in milliseconds (0 = use default)
 * @return TCA9534 error code
 */
tca9534_error_t TCA9534_STM32_Init(I2C_HandleTypeDef* hi2c, uint8_t device_addr, uint32_t timeout_ms) {
    if (hi2c == NULL) {
        return TCA9534_ERROR_NULL_PTR;
    }
    
    // Setup I2C context
    g_i2c_context.hi2c = hi2c;
    g_i2c_context.timeout_ms = (timeout_ms == 0) ? TCA9534_I2C_TIMEOUT_MS : timeout_ms;
    g_i2c_context.last_status = HAL_OK;
    
    // Initialize TCA9534 using C FFI interface
    return tca9534_init(&g_tca9534_handle, device_addr, &g_i2c_context, &g_i2c_ops);
}

/**
 * @brief Initialize TCA9534 with default settings
 * 
 * @param hi2c STM32 I2C handle pointer
 * @return TCA9534 error code
 */
tca9534_error_t TCA9534_STM32_Init_Default(I2C_HandleTypeDef* hi2c) {
    return TCA9534_STM32_Init(hi2c, TCA9534_ADDR_000, TCA9534_I2C_TIMEOUT_MS);
}

/**
 * @brief Get the global TCA9534 handle
 * 
 * @return Pointer to the global TCA9534 handle
 */
tca9534_handle_t* TCA9534_STM32_GetHandle(void) {
    return &g_tca9534_handle;
}

/**
 * @brief Get the last HAL I2C status
 * 
 * @return HAL status code
 */
HAL_StatusTypeDef TCA9534_STM32_GetLastHALStatus(void) {
    return g_i2c_context.last_status;
}

/**
 * @brief Check if TCA9534 device is ready
 * 
 * @return TCA9534_OK if device is ready, error code otherwise
 */
tca9534_error_t TCA9534_STM32_IsDeviceReady(void) {
    // Try to read the input port register to check if device responds
    uint8_t dummy_value;
    return tca9534_read_input_port(&g_tca9534_handle, &dummy_value);
}

// =============================================================================
// End of file
// ============================================================================= 